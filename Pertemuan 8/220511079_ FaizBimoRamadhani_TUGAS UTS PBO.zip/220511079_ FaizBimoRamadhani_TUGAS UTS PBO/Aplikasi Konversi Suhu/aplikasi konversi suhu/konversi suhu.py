import tkinter as tk

def konversi_suhu():
    try:
        suhu_input = float(entry_suhu.get())
        jenis_suhu_input = jenis_suhu.get()
        decimal_places = int(entry_decimal.get())

        if jenis_suhu_input == 'Celsius':
            suhu_celsius = suhu_input
            suhu_fahrenheit = (suhu_celsius * 9/5) + 32
            suhu_kelvin = suhu_celsius + 273.15
            suhu_reamur = suhu_celsius * 4/5
        elif jenis_suhu_input == 'Fahrenheit':
            suhu_fahrenheit = suhu_input
            suhu_celsius = (suhu_fahrenheit - 32) * 5/9
            suhu_kelvin = (suhu_fahrenheit - 32) * 5/9 + 273.15
            suhu_reamur = suhu_celsius * 4/5
        elif jenis_suhu_input == 'Kelvin':
            suhu_kelvin = suhu_input
            suhu_celsius = suhu_kelvin - 273.15
            suhu_fahrenheit = (suhu_kelvin - 273.15) * 9/5 + 32
            suhu_reamur = suhu_celsius * 4/5
        elif jenis_suhu_input == 'Reamur':
            suhu_reamur = suhu_input
            suhu_celsius = suhu_reamur * 5/4
            suhu_fahrenheit = (suhu_reamur * 9/4) + 32
            suhu_kelvin = suhu_celsius + 273.15

        result_text = f"Hasil konversi: {suhu_celsius:.{decimal_places}f} Celsius, {suhu_fahrenheit:.{decimal_places}f} Fahrenheit, {suhu_kelvin:.{decimal_places}f} Kelvin, {suhu_reamur:.{decimal_places}f} Reamur"
        label_hasil.config(text=result_text)
    except ValueError:
        label_hasil.config(text="Masukkan angka yang valid untuk suhu atau desimal.")

# Membuat instance dari tkinter
root = tk.Tk()
root.title("Konversi Suhu")

# Menambahkan style font
font_style = ('Helvetica', 12)

# Membuat label
label_suhu = tk.Label(root, text="Masukkan suhu:", font=font_style)
label_suhu.grid(row=0, column=0, padx=10, pady=10)

# Membuat entry (input) untuk suhu
entry_suhu = tk.Entry(root, font=font_style)
entry_suhu.grid(row=0, column=1, padx=10, pady=10)

# Membuat opsi pilihan untuk jenis suhu
jenis_suhu = tk.StringVar()
jenis_suhu.set('Celsius')  # Default jenis suhu

dropdown_jenis_suhu = tk.OptionMenu(root, jenis_suhu, 'Celsius', 'Fahrenheit', 'Kelvin', 'Reamur')
dropdown_jenis_suhu.grid(row=0, column=2, padx=10, pady=10)

# Menambahkan entry (input) untuk jumlah desimal
label_decimal = tk.Label(root, text="Jumlah Desimal:", font=font_style)
label_decimal.grid(row=1, column=0, padx=10, pady=10)

entry_decimal = tk.Entry(root, font=font_style)
entry_decimal.grid(row=1, column=1, padx=10, pady=10)

# Membuat tombol konversi
tombol_konversi = tk.Button(root, text="Konversi", command=konversi_suhu, font=font_style)
tombol_konversi.grid(row=2, column=0, columnspan=3, pady=10)

# Membuat label hasil konversi
label_hasil = tk.Label(root, text="Hasil konversi: ", font=font_style)
label_hasil.grid(row=3, column=0, columnspan=3, pady=10)

# Menjalankan loop utama tkinter
root.mainloop()
