import tkinter as tk
from tkinter import ttk
from googletrans import Translator

class TranslatorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Translator App")
        self.root.geometry("400x300")  # Set the initial size of the window

        # Font and color styles
        font_style = ('Arial', 12)
        label_color = '#333333'  # Dark gray
        button_color = '#4CAF50'  # Green

        # Source language label and combobox
        self.label_source = tk.Label(root, text="Bahasa Sumber:", font=font_style, fg=label_color)
        self.label_source.pack(pady=5)
        self.source_language = ttk.Combobox(root, values=["auto", "id", "en", "su", "ja"], state="readonly", font=font_style)
        self.source_language.set("auto")
        self.source_language.pack(pady=5)

        # Text entry label and entry
        self.label = tk.Label(root, text="Masukkan Teks:", font=font_style, fg=label_color)
        self.label.pack(pady=5)
        self.text_entry = tk.Entry(root, width=40, font=font_style)
        self.text_entry.pack(pady=5)

        # Target language label and combobox
        self.label_target = tk.Label(root, text="Bahasa Target:", font=font_style, fg=label_color)
        self.label_target.pack(pady=5)
        self.target_language = ttk.Combobox(root, values=["id", "en", "su", "ja"], state="readonly", font=font_style)
        self.target_language.set("en")
        self.target_language.pack(pady=5)

        # Translate button
        self.translate_button = tk.Button(root, text="Terjemahkan", command=self.translate_text, font=font_style, bg=button_color, fg='white')
        self.translate_button.pack(pady=10)

        # Result label
        self.result_label = tk.Label(root, text="", font=font_style, fg=label_color)
        self.result_label.pack(pady=10)

    def translate_text(self):
        text_to_translate = self.text_entry.get()
        source_lang = self.source_language.get()
        target_lang = self.target_language.get()

        translator = Translator()
        translated_text = translator.translate(text_to_translate, src=source_lang, dest=target_lang).text

        result = f"{target_lang.capitalize()}: {translated_text}"
        self.result_label.config(text=result)

if __name__ == "__main__":
    root = tk.Tk()
    app = TranslatorApp(root)
    root.mainloop()
